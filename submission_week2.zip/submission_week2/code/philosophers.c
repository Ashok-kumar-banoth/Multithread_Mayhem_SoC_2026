#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#define NUM_PHILOSOPHERS 5
#define MEALS_PER_PHILOSOPHER 10

pthread_mutex_t forks[NUM_PHILOSOPHERS];

typedef struct {
    int id;
    int meals_eaten;
} philosopher_t;

void *philosopher(void *arg)
{
    philosopher_t *p = (philosopher_t *)arg;

    int left = p->id;
    int right = (p->id + 1) % NUM_PHILOSOPHERS;

    /* Lock ordering fix:
       Always lock lower-numbered fork first */
    int first = (left < right) ? left : right;
    int second = (left < right) ? right : left;

    for (int meal = 0; meal < MEALS_PER_PHILOSOPHER; meal++)
    {
        printf("Philosopher %d is thinking\n", p->id);

        usleep(50000);

        pthread_mutex_lock(&forks[first]);
        pthread_mutex_lock(&forks[second]);

        printf("Philosopher %d is eating meal %d\n",
               p->id,
               meal + 1);

        p->meals_eaten++;

        usleep(50000);

        pthread_mutex_unlock(&forks[second]);
        pthread_mutex_unlock(&forks[first]);
    }

    return NULL;
}

int main(void)
{
    pthread_t threads[NUM_PHILOSOPHERS];
    philosopher_t philosophers[NUM_PHILOSOPHERS];

    for (int i = 0; i < NUM_PHILOSOPHERS; i++)
    {
        pthread_mutex_init(&forks[i], NULL);
    }

    for (int i = 0; i < NUM_PHILOSOPHERS; i++)
    {
        philosophers[i].id = i;
        philosophers[i].meals_eaten = 0;

        pthread_create(
            &threads[i],
            NULL,
            philosopher,
            &philosophers[i]);
    }

    for (int i = 0; i < NUM_PHILOSOPHERS; i++)
    {
        pthread_join(threads[i], NULL);
    }

    printf("\n=== SUMMARY ===\n");

    for (int i = 0; i < NUM_PHILOSOPHERS; i++)
    {
        printf("Philosopher %d ate %d meals\n",
               i,
               philosophers[i].meals_eaten);
    }

    for (int i = 0; i < NUM_PHILOSOPHERS; i++)
    {
        pthread_mutex_destroy(&forks[i]);
    }

    return 0;
}