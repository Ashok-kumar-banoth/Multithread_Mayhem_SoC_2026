#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>

#define NUM_THREADS 8
#define OPS_PER_THREAD 1000

typedef struct Node {
    int value;
    struct Node *next;
} Node;

Node *head = NULL;

pthread_mutex_t list_lock;

/* ---------- API ---------- */

void list_init(void)
{
    head = NULL;
    pthread_mutex_init(&list_lock, NULL);
}

void list_insert(int value)
{
    pthread_mutex_lock(&list_lock);

    Node *new_node = malloc(sizeof(Node));
    new_node->value = value;
    new_node->next = head;
    head = new_node;

    pthread_mutex_unlock(&list_lock);
}

int list_contains(int value)
{
    pthread_mutex_lock(&list_lock);

    Node *curr = head;

    while (curr)
    {
        if (curr->value == value)
        {
            pthread_mutex_unlock(&list_lock);
            return 1;
        }

        curr = curr->next;
    }

    pthread_mutex_unlock(&list_lock);
    return 0;
}

void list_remove(int value)
{
    pthread_mutex_lock(&list_lock);

    Node *curr = head;
    Node *prev = NULL;

    while (curr)
    {
        if (curr->value == value)
        {
            if (prev)
                prev->next = curr->next;
            else
                head = curr->next;

            free(curr);
            break;
        }

        prev = curr;
        curr = curr->next;
    }

    pthread_mutex_unlock(&list_lock);
}

void list_destroy(void)
{
    pthread_mutex_lock(&list_lock);

    Node *curr = head;

    while (curr)
    {
        Node *tmp = curr;
        curr = curr->next;
        free(tmp);
    }

    head = NULL;

    pthread_mutex_unlock(&list_lock);

    pthread_mutex_destroy(&list_lock);
}

/* ---------- Test ---------- */

void *worker(void *arg)
{
    (void)arg;

    for (int i = 0; i < OPS_PER_THREAD; i++)
    {
        int value = rand() % 100;
        int op = rand() % 3;

        if (op == 0)
            list_insert(value);
        else if (op == 1)
            list_remove(value);
        else
            list_contains(value);
    }

    return NULL;
}

int main(void)
{
    srand(time(NULL));

    list_init();

    pthread_t threads[NUM_THREADS];

    for (int i = 0; i < NUM_THREADS; i++)
    {
        pthread_create(&threads[i], NULL, worker, NULL);
    }

    for (int i = 0; i < NUM_THREADS; i++)
    {
        pthread_join(threads[i], NULL);
    }

    printf("All worker threads finished.\n");

    int count = 0;

    Node *curr = head;

    while (curr)
    {
        count++;
        curr = curr->next;
    }

    printf("List is well formed.\n");
    printf("Final node count: %d\n", count);

    printf("Contains(50) = %d\n", list_contains(50));

    list_destroy();

    printf("List destroyed successfully.\n");

    return 0;
}