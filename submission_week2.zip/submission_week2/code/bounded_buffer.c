#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define BUFFER_CAPACITY 5
#define NUM_PRODUCERS 3
#define NUM_CONSUMERS 2
#define ITEMS_PER_PRODUCER 1000

/* ================= BUFFER ================= */

int *buffer;
int capacity;
int count = 0;
int in = 0;
int out = 0;

pthread_mutex_t buffer_lock;
pthread_cond_t not_full;
pthread_cond_t not_empty;

void buffer_init(int cap)
{
    capacity = cap;
    buffer = malloc(capacity * sizeof(int));

    pthread_mutex_init(&buffer_lock, NULL);
    pthread_cond_init(&not_full, NULL);
    pthread_cond_init(&not_empty, NULL);
}

void buffer_put(int item)
{
    pthread_mutex_lock(&buffer_lock);

    while (count == capacity)
    {
        pthread_cond_wait(&not_full, &buffer_lock);
    }

    buffer[in] = item;
    in = (in + 1) % capacity;
    count++;

    pthread_cond_signal(&not_empty);

    pthread_mutex_unlock(&buffer_lock);
}

int buffer_get(void)
{
    pthread_mutex_lock(&buffer_lock);

    while (count == 0)
    {
        pthread_cond_wait(&not_empty, &buffer_lock);
    }

    int item = buffer[out];

    out = (out + 1) % capacity;
    count--;

    pthread_cond_signal(&not_full);

    pthread_mutex_unlock(&buffer_lock);

    return item;
}

void buffer_destroy(void)
{
    free(buffer);

    pthread_mutex_destroy(&buffer_lock);
    pthread_cond_destroy(&not_full);
    pthread_cond_destroy(&not_empty);
}

/* ================= STATS ================= */

long produced_count = 0;
long consumed_count = 0;

long produced_sum = 0;
long consumed_sum = 0;

pthread_mutex_t stats_lock = PTHREAD_MUTEX_INITIALIZER;

/* ================= PRODUCER ================= */

void *producer(void *arg)
{
    int id = *(int *)arg;

    int start = id * 1000;

    for (int i = 0; i < ITEMS_PER_PRODUCER; i++)
    {
        int item = start + i;

        buffer_put(item);

        pthread_mutex_lock(&stats_lock);

        produced_count++;
        produced_sum += item;

        pthread_mutex_unlock(&stats_lock);
    }

    return NULL;
}

/* ================= CONSUMER ================= */

void *consumer(void *arg)
{
    (void)arg;

    while (1)
    {
        int item = buffer_get();

        /* -1 means terminate */
        if (item == -1)
        {
            break;
        }

        pthread_mutex_lock(&stats_lock);

        consumed_count++;
        consumed_sum += item;

        pthread_mutex_unlock(&stats_lock);
    }

    return NULL;
}

/* ================= MAIN ================= */

int main(void)
{
    buffer_init(BUFFER_CAPACITY);

    pthread_t producers[NUM_PRODUCERS];
    pthread_t consumers[NUM_CONSUMERS];

    int ids[NUM_PRODUCERS];

    /* Start consumers */
    for (int i = 0; i < NUM_CONSUMERS; i++)
    {
        pthread_create(&consumers[i], NULL, consumer, NULL);
    }

    /* Start producers */
    for (int i = 0; i < NUM_PRODUCERS; i++)
    {
        ids[i] = i;

        pthread_create(
            &producers[i],
            NULL,
            producer,
            &ids[i]);
    }

    /* Wait for producers */
    for (int i = 0; i < NUM_PRODUCERS; i++)
    {
        pthread_join(producers[i], NULL);
    }

    /* Send termination signals */
    for (int i = 0; i < NUM_CONSUMERS; i++)
    {
        buffer_put(-1);
    }

    /* Wait for consumers */
    for (int i = 0; i < NUM_CONSUMERS; i++)
    {
        pthread_join(consumers[i], NULL);
    }

    printf("Produced Count : %ld\n", produced_count);
    printf("Consumed Count : %ld\n", consumed_count);

    printf("Produced Sum   : %ld\n", produced_sum);
    printf("Consumed Sum   : %ld\n", consumed_sum);

    if (produced_count == consumed_count &&
        produced_sum == consumed_sum)
    {
        printf("\nVerification PASSED\n");
    }
    else
    {
        printf("\nVerification FAILED\n");
    }

    pthread_mutex_destroy(&stats_lock);
    buffer_destroy();

    return 0;
}