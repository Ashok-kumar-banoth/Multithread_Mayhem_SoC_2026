#include "kernel/types.h"
#include "user/user.h"

int main(int argc, char *argv[])
{
    int N = 5;

    if(argc > 1)
        N = atoi(argv[1]);

    int i;
    int parent = getpid();

    for(i = 0; i < N; i++){

        int pid = fork();

        if(pid < 0){
            printf("fork failed\n");
            exit(1);
        }

        if(pid == 0){
            printf("Depth %d: PID %d, Parent PID %d\n",
                   i, getpid(), parent);

            parent = getpid();
        }
        else{
            wait(0);
            break;
        }
    }

    if(i == N){
        printf("I am the leaf! No more children.\n");
    }

    printf("Total processes in chain: %d\n", N);

    exit(0);
}
