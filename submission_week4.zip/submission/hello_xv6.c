#include "kernel/types.h"
#include "user/user.h"

int main(int argc, char *argv[])
{
    printf("Hello xv6! This is Problem 1\n");

    printf("Arguments count: %d\n", argc);

    for(int i = 0; i < argc; i++){
        printf("argv[%d] = %s\n", i, argv[i]);
    }

    exit(0);
}
