#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
int main(void)
{
    int mypid = getpid();

    printf("Syscall Spy Report for PID %d:\n", mypid);

    // getpid
    printf("getpid() -> %d\n", mypid);

    // uptime
    printf("uptime() -> %d\n", uptime());

    // fork
    int pid = fork();

    if(pid < 0){
        printf("fork() failed\n");
        exit(1);
    }

    if(pid == 0){
        printf("--- in child (PID %d) ---\n", getpid());
        printf("I am the child!\n");
        printf("getpid() -> %d\n", getpid());
        exit(0);
    }

    // parent
    printf("fork() -> %d (child PID)\n", pid);

    int ret;

    // sleep
    ret = pause(10);
    printf("pause(10) -> %d\n", ret);

    // write
    ret = write(1, "Hello, world!\n", 14);
    printf("write(1, ...) -> %d\n", ret);

    // dup
    ret = dup(0);
    printf("dup(0) -> %d\n", ret);

    // wait
    int childpid = wait(0);

    printf("--- back in parent (PID %d) ---\n", mypid);
    printf("wait() -> %d (reaped child PID %d)\n",
           childpid, pid);

    exit(0);
}
