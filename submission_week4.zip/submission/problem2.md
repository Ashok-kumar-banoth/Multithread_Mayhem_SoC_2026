# Problem 2 – Codebase Detective

## A. Process States

The five possible states of an xv6 process are:
- UNUSED
- SLEEPING
- RUNNABLE
- RUNNING
- ZOMBIE

After fork(), the child process is in RUNNABLE state.

Between exit() and wait(), the process is in ZOMBIE state.

---

## B. Boot Process

Initialization steps in kernel/main.c:

consoleinit()
printkinit()
kinit()
kvminit()
kvminithart()
procinit()
trapinit()
trapinithart()
plicinit()
plicinithart()
binit()
iinit()
fileinit()
virtio_disk_init()
userinit()
scheduler()

The first subsystem initialized is consoleinit().

The last subsystem initialized before scheduling begins is userinit().

scheduler() continuously searches for RUNNABLE processes and allocates CPU time to them.

---

## C. System Call Table

xv6 currently supports 21 system calls.

The system call numbers defined in syscall.h are used as indices into the syscalls[] array in syscall.c. Each index maps directly to a corresponding handler function.

If an invalid system call number is used, xv6 prints an "unknown sys call" message and returns -1.

---

## D. Shell

The shell executes commands by creating a child process using fork(). The child process executes the command using exec(), while the parent waits using wait().

For a pipe such as:

ls | cat

xv6 creates a pipe, forks two child processes, redirects output of the first command to the pipe, redirects input of the second command from the pipe, and waits for both processes to finish.

## Problems Attempted

I attempted Problems 1, 2, 3 and 4.

## Interesting Observations

While working with xv6, I observed how user programs are compiled and included in the filesystem image through the UPROGS section of the Makefile. I also learned how process creation works using fork() and how parent and child processes execute concurrently.

## What Surprised Me

One surprising aspect was that my xv6 version did not provide some system calls commonly available in Linux, such as getppid() and sleep(). Instead, the custom xv6 used a pause() system call.

## Difficulties Faced

Initially I faced issues while adding new user programs to xv6 because programs must be explicitly added to the UPROGS list in the Makefile. I also encountered build errors related to unavailable system calls and learned how to adapt the code to the specific xv6 version provided for the course.
