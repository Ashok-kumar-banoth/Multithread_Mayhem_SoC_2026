/*
 * sem_buffer.c
 *
 * Week 3 - Problem 2
 * Semaphore-based Bounded Buffer
 *
 * Compile:
 * gcc -Wall -pthread -std=c11 sem_buffer.c -o sem_buffer
 *
 * Run:
 * ./sem_buffer
 */

#define _DEFAULT_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

#define BUFFER_SIZE 5
#define NUM_PRODUCERS 3
#define NUM_CONSUMERS 2
#define ITEMS_PER_PRODUCER 1000

typedef struct
{
    int *data;
    int capacity;

    int in;
    int out;
    int count;

    sem_t empty;
    sem_t full;

    pthread_mutex_t mutex;

} buffer_t;

buffer_t buffer;

long long produced_sum = 0;
long long consumed_sum = 0;

int produced_count = 0;
int consumed_count = 0;

pthread_mutex_t stats_mutex = PTHREAD_MUTEX_INITIALIZER;

/* --------------------------------------------------------- */
/* Buffer Functions                                           */
/* --------------------------------------------------------- */

void buffer_init(int capacity)
{
    buffer.capacity = capacity;

    buffer.data = malloc(sizeof(int) * capacity);

    buffer.in = 0;
    buffer.out = 0;
    buffer.count = 0;

    sem_init(&buffer.empty, 0, capacity);
    sem_init(&buffer.full, 0, 0);

    pthread_mutex_init(&buffer.mutex, NULL);
}

void buffer_put(int item)
{
    sem_wait(&buffer.empty);

    pthread_mutex_lock(&buffer.mutex);

    buffer.data[buffer.in] = item;

    buffer.in = (buffer.in + 1) % buffer.capacity;

    buffer.count++;

    pthread_mutex_unlock(&buffer.mutex);

    sem_post(&buffer.full);
}

int buffer_get(void)
{
    sem_wait(&buffer.full);

    pthread_mutex_lock(&buffer.mutex);

    int item = buffer.data[buffer.out];

    buffer.out = (buffer.out + 1) % buffer.capacity;

    buffer.count--;

    pthread_mutex_unlock(&buffer.mutex);

    sem_post(&buffer.empty);

    return item;
}

void buffer_destroy(void)
{
    free(buffer.data);

    sem_destroy(&buffer.empty);
    sem_destroy(&buffer.full);

    pthread_mutex_destroy(&buffer.mutex);
}

/* --------------------------------------------------------- */
/* Producer                                                   */
/* --------------------------------------------------------- */

void *producer(void *arg)
{
    int id = *(int *)arg;

    int start = id * ITEMS_PER_PRODUCER;

    for (int i = 0; i < ITEMS_PER_PRODUCER; i++)
    {
        int item = start + i;

        buffer_put(item);

        pthread_mutex_lock(&stats_mutex);

        produced_count++;
        produced_sum += item;

        pthread_mutex_unlock(&stats_mutex);
    }

    return NULL;
}

/* --------------------------------------------------------- */
/* Consumer                                                   */
/* --------------------------------------------------------- */

void *consumer(void *arg)
{
    (void)arg;

    int items_to_consume =
        (NUM_PRODUCERS * ITEMS_PER_PRODUCER)
        / NUM_CONSUMERS;

    for (int i = 0; i < items_to_consume; i++)
    {
        int item = buffer_get();

        pthread_mutex_lock(&stats_mutex);

        consumed_count++;
        consumed_sum += item;

        pthread_mutex_unlock(&stats_mutex);
    }

    return NULL;
}

/* --------------------------------------------------------- */
/* Main                                                       */
/* --------------------------------------------------------- */

int main(void)
{
    buffer_init(BUFFER_SIZE);

    pthread_t producers[NUM_PRODUCERS];
    pthread_t consumers[NUM_CONSUMERS];

    int producer_ids[NUM_PRODUCERS];

    for (int i = 0; i < NUM_PRODUCERS; i++)
    {
        producer_ids[i] = i;

        pthread_create(
            &producers[i],
            NULL,
            producer,
            &producer_ids[i]);
    }

    for (int i = 0; i < NUM_CONSUMERS; i++)
    {
        pthread_create(
            &consumers[i],
            NULL,
            consumer,
            NULL);
    }

    for (int i = 0; i < NUM_PRODUCERS; i++)
    {
        pthread_join(producers[i], NULL);
    }

    for (int i = 0; i < NUM_CONSUMERS; i++)
    {
        pthread_join(consumers[i], NULL);
    }

    printf("\n=== Verification ===\n\n");

    printf("Produced Count : %d\n",
           produced_count);

    printf("Consumed Count : %d\n\n",
           consumed_count);

    printf("Produced Sum   : %lld\n",
           produced_sum);

    printf("Consumed Sum   : %lld\n\n",
           consumed_sum);

    if (produced_count == consumed_count &&
        produced_sum == consumed_sum)
    {
        printf("Verification PASSED\n");
    }
    else
    {
        printf("Verification FAILED\n");
    }

    buffer_destroy();

    pthread_mutex_destroy(&stats_mutex);

    return 0;
}