#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

#define SIZE 10
#define READERS 5
#define WRITERS 2
#define WRITES_PER_WRITER 3

int db[SIZE];

pthread_mutex_t read_count_mutex;
pthread_mutex_t resource_mutex;

int read_count = 0;

/* -------------------- Reader -------------------- */

void* reader(void* arg)
{
    int id = *(int*)arg;

    for (int i = 0; i < 5; i++)
    {
        pthread_mutex_lock(&read_count_mutex);

        read_count++;

        if (read_count == 1)
        {
            pthread_mutex_lock(&resource_mutex);
        }

        pthread_mutex_unlock(&read_count_mutex);

        // reading section
        printf("[READER %d] reading db[0]=%d\n", id, db[0]);
        usleep(50000);

        pthread_mutex_lock(&read_count_mutex);

        read_count--;

        if (read_count == 0)
        {
            pthread_mutex_unlock(&resource_mutex);
        }

        pthread_mutex_unlock(&read_count_mutex);

        usleep(50000);
    }

    return NULL;
}

/* -------------------- Writer -------------------- */

void* writer(void* arg)
{
    int id = *(int*)arg;

    for (int i = 0; i < WRITES_PER_WRITER; i++)
    {
        pthread_mutex_lock(&resource_mutex);

        db[0] += 1;

        printf("[WRITER %d] wrote db[0]=%d\n", id, db[0]);

        usleep(80000);

        pthread_mutex_unlock(&resource_mutex);
    }

    return NULL;
}

/* -------------------- MAIN -------------------- */

int main()
{
    pthread_t r[READERS], w[WRITERS];
    int rid[READERS], wid[WRITERS];

    pthread_mutex_init(&read_count_mutex, NULL);
    pthread_mutex_init(&resource_mutex, NULL);

    for (int i = 0; i < SIZE; i++)
        db[i] = i;

    for (int i = 0; i < READERS; i++)
    {
        rid[i] = i;
        pthread_create(&r[i], NULL, reader, &rid[i]);
    }

    for (int i = 0; i < WRITERS; i++)
    {
        wid[i] = i;
        pthread_create(&w[i], NULL, writer, &wid[i]);
    }

    for (int i = 0; i < READERS; i++)
        pthread_join(r[i], NULL);

    for (int i = 0; i < WRITERS; i++)
        pthread_join(w[i], NULL);

    pthread_mutex_destroy(&read_count_mutex);
    pthread_mutex_destroy(&resource_mutex);

    printf("\nFinal db[0] = %d\n", db[0]);

    return 0;
}