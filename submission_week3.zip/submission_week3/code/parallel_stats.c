/*
 * parallel_stats.c
 *
 * Week 3 - Problem 1
 * Parallel Statistics using Pthreads
 *
 * Compile:
 * gcc -Wall -pthread -std=c11 parallel_stats.c -o parallel_stats
 *
 * Run:
 * ./parallel_stats
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <limits.h>

#define ARRAY_SIZE 1000000
#define NUM_THREADS 4

typedef struct
{
    int *array;
    int start;
    int end;

    long long partial_sum;
    int partial_min;
    int partial_max;

} worker_result_t;

void *worker(void *arg)
{
    worker_result_t *r = (worker_result_t *)arg;

    long long sum = 0;
    int min = r->array[r->start];
    int max = r->array[r->start];

    for (int i = r->start; i < r->end; i++)
    {
        int value = r->array[i];

        sum += value;

        if (value < min)
            min = value;

        if (value > max)
            max = value;
    }

    r->partial_sum = sum;
    r->partial_min = min;
    r->partial_max = max;

    return NULL;
}

int main(void)
{
    int *array = malloc(sizeof(int) * ARRAY_SIZE);

    if (array == NULL)
    {
        printf("Memory allocation failed\n");
        return 1;
    }

    for (int i = 0; i < ARRAY_SIZE; i++)
    {
        array[i] = i + 1;
    }

    pthread_t threads[NUM_THREADS];
    worker_result_t workers[NUM_THREADS];

    int chunk_size = ARRAY_SIZE / NUM_THREADS;

    for (int i = 0; i < NUM_THREADS; i++)
    {
        workers[i].array = array;
        workers[i].start = i * chunk_size;

        if (i == NUM_THREADS - 1)
            workers[i].end = ARRAY_SIZE;
        else
            workers[i].end = (i + 1) * chunk_size;

        pthread_create(
            &threads[i],
            NULL,
            worker,
            &workers[i]);
    }

    for (int i = 0; i < NUM_THREADS; i++)
    {
        pthread_join(threads[i], NULL);
    }

    long long total_sum = 0;
    int global_min = INT_MAX;
    int global_max = INT_MIN;

    printf("=== Per Thread Statistics ===\n\n");

    for (int i = 0; i < NUM_THREADS; i++)
    {
        printf("Thread %d\n", i);
        printf("  Range : [%d, %d)\n",
               workers[i].start,
               workers[i].end);

        printf("  Sum   : %lld\n",
               workers[i].partial_sum);

        printf("  Min   : %d\n",
               workers[i].partial_min);

        printf("  Max   : %d\n\n",
               workers[i].partial_max);

        total_sum += workers[i].partial_sum;

        if (workers[i].partial_min < global_min)
            global_min = workers[i].partial_min;

        if (workers[i].partial_max > global_max)
            global_max = workers[i].partial_max;
    }

    double average =
        (double)total_sum / ARRAY_SIZE;

    printf("=== Final Statistics ===\n\n");
    printf("Total Sum : %lld\n", total_sum);
    printf("Minimum   : %d\n", global_min);
    printf("Maximum   : %d\n", global_max);
    printf("Average   : %.2f\n", average);

    free(array);

    return 0;
}