/*
 * thread_pool.c
 *
 * Week 3 - Problem 4
 *
 * Compile:
 * gcc -Wall -pthread -std=c11 thread_pool.c -o thread_pool
 *
 * Run:
 * ./thread_pool
 */

#define _DEFAULT_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#define NUM_WORKERS 4
#define NUM_TASKS   100

typedef struct task
{
    void (*fn)(void *);
    void *arg;

    struct task *next;

} task_t;

pthread_t workers[NUM_WORKERS];

task_t *queue_head = NULL;
task_t *queue_tail = NULL;

pthread_mutex_t queue_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t work_available = PTHREAD_COND_INITIALIZER;
pthread_cond_t all_done = PTHREAD_COND_INITIALIZER;

int shutdown_pool = 0;

int pending_tasks = 0;
int active_workers = 0;

int completed_tasks = 0;

/* -------------------------------------------------- */
/* Worker Thread                                      */
/* -------------------------------------------------- */

void *worker_thread(void *arg)
{
    (void)arg;

    while (1)
    {
        pthread_mutex_lock(&queue_mutex);

        while (queue_head == NULL && !shutdown_pool)
        {
            pthread_cond_wait(
                &work_available,
                &queue_mutex);
        }

        if (shutdown_pool && queue_head == NULL)
        {
            pthread_mutex_unlock(&queue_mutex);
            break;
        }

        task_t *task = queue_head;

        queue_head = queue_head->next;

        if (queue_head == NULL)
            queue_tail = NULL;

        active_workers++;

        pthread_mutex_unlock(&queue_mutex);

        task->fn(task->arg);

        free(task->arg);
        free(task);

        pthread_mutex_lock(&queue_mutex);

        active_workers--;
        pending_tasks--;
        completed_tasks++;

        if (pending_tasks == 0 &&
            active_workers == 0)
        {
            pthread_cond_signal(&all_done);
        }

        pthread_mutex_unlock(&queue_mutex);
    }

    return NULL;
}

/* -------------------------------------------------- */
/* Pool API                                           */
/* -------------------------------------------------- */

void pool_init(int workers_count)
{
    for (int i = 0; i < workers_count; i++)
    {
        pthread_create(
            &workers[i],
            NULL,
            worker_thread,
            NULL);
    }
}

void pool_submit(void (*fn)(void *), void *arg)
{
    task_t *task = malloc(sizeof(task_t));

    task->fn = fn;
    task->arg = arg;
    task->next = NULL;

    pthread_mutex_lock(&queue_mutex);

    if (queue_tail == NULL)
    {
        queue_head = task;
        queue_tail = task;
    }
    else
    {
        queue_tail->next = task;
        queue_tail = task;
    }

    pending_tasks++;

    pthread_cond_signal(&work_available);

    pthread_mutex_unlock(&queue_mutex);
}

void pool_wait(void)
{
    pthread_mutex_lock(&queue_mutex);

    while (pending_tasks > 0 ||
           active_workers > 0)
    {
        pthread_cond_wait(
            &all_done,
            &queue_mutex);
    }

    pthread_mutex_unlock(&queue_mutex);
}

void pool_destroy(void)
{
    pthread_mutex_lock(&queue_mutex);

    shutdown_pool = 1;

    pthread_cond_broadcast(&work_available);

    pthread_mutex_unlock(&queue_mutex);

    for (int i = 0; i < NUM_WORKERS; i++)
    {
        pthread_join(workers[i], NULL);
    }

    pthread_mutex_destroy(&queue_mutex);
    pthread_cond_destroy(&work_available);
    pthread_cond_destroy(&all_done);
}

/* -------------------------------------------------- */
/* Example Task                                       */
/* -------------------------------------------------- */

void example_task(void *arg)
{
    int id = *(int *)arg;

    usleep(10000);

    printf("Task %d executed\n", id);
}

/* -------------------------------------------------- */
/* Main                                               */
/* -------------------------------------------------- */

int main(void)
{
    pool_init(NUM_WORKERS);

    for (int i = 0; i < NUM_TASKS; i++)
    {
        int *id = malloc(sizeof(int));

        *id = i;

        pool_submit(
            example_task,
            id);
    }

    pool_wait();

    printf("\nCompleted Tasks : %d\n",
           completed_tasks);

    if (completed_tasks == NUM_TASKS)
    {
        printf("Verification PASSED\n");
    }
    else
    {
        printf("Verification FAILED\n");
    }

    pool_destroy();

    return 0;
}